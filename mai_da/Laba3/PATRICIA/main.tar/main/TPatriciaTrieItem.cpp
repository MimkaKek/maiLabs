#include "TPatriciaTrieItem.h"
#include <cstring>
#include <cstdlib>

//----------------------------------------------------------------------------
template <class T>
TPatriciaTrieItem<T>::TPatriciaTrieItem() {
    Initialize(nullptr, 0, -1, this, this);
}

//----------------------------------------------------------------------------
template <class T>
TPatriciaTrieItem<T>::TPatriciaTrieItem(char* nkey, T ndata, int nidx, TPatriciaTrieItem<T>* nleft, TPatriciaTrieItem<T>* nright) {
    Initialize(nkey, ndata, nidx, nleft, nright);
}

//----------------------------------------------------------------------------
template <class T>
void TPatriciaTrieItem<T>::Initialize(char* nkey, T ndata, int nidx, TPatriciaTrieItem<T>* nleft, TPatriciaTrieItem<T>* nright) {
    
    if (nkey) {
        key = (char*)strdup(nkey);
    }
    else {
        key = nkey;
    }
    
    data      = ndata;
    index     = nidx;
    left      = nleft;
    right     = nright;
}

//----------------------------------------------------------------------------
template <class T>
TPatriciaTrieItem<T>::~TPatriciaTrieItem() {
    if (key) {
        free(key);
        key = NULL;
    }
}

template class TPatriciaTrieItem<unsigned long long int>;
