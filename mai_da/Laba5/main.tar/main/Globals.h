#ifndef GLOBALS_H
#define GLOBALS_H

#include <cstdint>
const char      SENTINEL = '$';
const size_t    INTERNAL = SIZE_MAX;

#endif
