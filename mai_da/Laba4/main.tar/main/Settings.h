#ifndef PROP
#define PROP

const int   DEBUG_GET_NUMB_PATTERN  = 0;
const int   DEBUG_GET_NUMB_STR      = 0;
const int   DEBUG_WORK_WITH_STACK   = 0;
const int   DEBUG_PARAM_FUN         = 0;
const int   DEBUG_STACK_ACT         = 0;
const int   DEBUG_GET_EMPTY_STR     = 0;
const int   DEBUG_GET_NEW_STR       = 0;
const int   DEBUG_SEARCH            = 0;

#endif
